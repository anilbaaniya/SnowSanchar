import { useState, useEffect, useTransition, useCallback } from "react";
import Footer from "../ui/Footer";
import ImageContainer from "../ui/ImageContainer";
import { teejImages } from "../features/kathmandu/teej";
import { littleSnowImages } from "../features/kathmandu/little-snow";

/* ─── Preload a batch of images in the background ─────────────────────────── */
function preloadImages(urls = []) {
  urls.forEach((url) => {
    const img = new Image();
    img.src = url;
  });
}

/* ─── Tailwind shimmer keyframe (inject once) ─────────────────────────────── */
const shimmerStyle = `
  @keyframes shimmer {
    0%   { background-position: -400px 0; }
    100% { background-position:  400px 0; }
  }
  .animate-shimmer {
    background-size: 800px 100%;
    animation: shimmer 1.4s infinite linear;
  }
`;

export default function Kathmandu() {
  const [program, setProgram] = useState("little-snow");
  const [isPending, startTransition] = useTransition();

  const currentImages =
    program === "little-snow" ? littleSnowImages : teejImages;

  /* Preload the OTHER program's images while the user views the current one */
  useEffect(() => {
    const other = program === "little-snow" ? teejImages : littleSnowImages;
    const id = setTimeout(() => preloadImages(other), 1500);
    return () => clearTimeout(id);
  }, [program]);

  /* Inject shimmer CSS once */
  useEffect(() => {
    if (document.getElementById("shimmer-style")) return;
    const tag = document.createElement("style");
    tag.id = "shimmer-style";
    tag.textContent = shimmerStyle;
    document.head.appendChild(tag);
  }, []);

  const handleSwitch = useCallback((next) => {
    if (next === program) return;
    startTransition(() => setProgram(next));
  }, [program]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <section className="text-center pt-12 pb-4 px-4">
        <h1 className="text-3xl md:text-5xl font-bold tracking-tight text-gray-900">
          Kathmandu Contestants
        </h1>
        <p className="mt-3 text-sm md:text-base max-w-2xl mx-auto text-gray-600">
          Meet the amazing participants from Kathmandu district.
        </p>
      </section>

      {/* Program Selector */}
      <div className="flex justify-center gap-4 my-8 px-4">
        <button
          onClick={() => handleSwitch("little-snow")}
          disabled={isPending}
          className={`px-6 py-3 rounded-full font-semibold text-sm md:text-base transition-all duration-300 shadow-md cursor-pointer disabled:opacity-60
            ${
              program === "little-snow"
                ? "bg-blue-600 text-white shadow-blue-300 scale-105"
                : "bg-white text-gray-700 border border-gray-300 hover:bg-blue-50 hover:text-blue-600 hover:scale-105"
            }`}
        >
          Little Snow
        </button>

        <button
          onClick={() => handleSwitch("teej")}
          disabled={isPending}
          className={`px-6 py-3 rounded-full font-semibold text-sm md:text-base transition-all duration-300 shadow-md cursor-pointer disabled:opacity-60
            ${
              program === "teej"
                ? "bg-pink-600 text-white shadow-pink-300 scale-105"
                : "bg-white text-gray-700 border border-gray-300 hover:bg-pink-50 hover:text-pink-600 hover:scale-105"
            }`}
        >
          Teej
        </button>
      </div>

      {/* Gallery */}
      <ImageContainer
        images={currentImages}
        district="Kathmandu"
        isLoading={isPending}
      />

      <Footer />
    </div>
  );
}
