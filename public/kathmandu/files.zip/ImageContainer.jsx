import { useEffect, useRef, useState, memo, useMemo } from "react";

/* ─── Single lazy-loaded card ─────────────────────────────────────────────── */
const ImageCard = memo(function ImageCard({ src, district, index }) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [inView, setInView] = useState(false);
  const ref = useRef(null);

  /* Observe when the card enters the viewport, then start loading */
  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { rootMargin: "200px" } // start loading 200px before visible
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="group relative overflow-hidden rounded-2xl bg-white shadow-md hover:shadow-xl transition-all duration-300 transform-gpu hover:-translate-y-1"
      style={{ minHeight: "16rem" }}
    >
      {/* Skeleton shimmer — shown until image loads */}
      {!loaded && !error && (
        <div className="absolute inset-0 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 animate-shimmer" />
      )}

      {/* Error state */}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100 text-gray-400 gap-2">
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
              d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <span className="text-xs">Failed to load</span>
        </div>
      )}

      {/* Actual image — only mounted after IntersectionObserver fires */}
      {inView && (
        <img
          src={src}
          alt={`${district} Contestant ${index + 1}`}
          decoding="async"
          onLoad={() => setLoaded(true)}
          onError={() => { setLoaded(true); setError(true); }}
          className={`w-full h-64 object-cover object-top transition-opacity duration-500 ${
            loaded ? "opacity-100" : "opacity-0"
          }`}
        />
      )}

      {/* Hover overlays — only rendered once image is loaded */}
      {loaded && !error && (
        <>
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300" />
          <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
            <p className="text-white font-semibold text-sm">Contestant {index + 1}</p>
          </div>
          <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
        </>
      )}
    </div>
  );
});

/* ─── Full-screen loading spinner ─────────────────────────────────────────── */
function LoadingSpinner() {
  return (
    <div className="flex-1 flex items-center justify-center py-24">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 rounded-full border-4 border-gray-200 border-t-blue-500 animate-spin" />
        <p className="text-sm text-gray-500 font-medium">Loading images…</p>
      </div>
    </div>
  );
}

/* ─── Main container ───────────────────────────────────────────────────────── */
export default function ImageContainer({ images, district, isLoading = false }) {
  /* Memoize so the list reference is stable between renders */
  const stableImages = useMemo(() => images, [images]);

  if (isLoading) return <LoadingSpinner />;

  if (!stableImages?.length) {
    return (
      <div className="flex-1 flex items-center justify-center py-24">
        <p className="text-gray-400 text-sm">No images available.</p>
      </div>
    );
  }

  return (
    <main className="flex-1 px-4 pb-10">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
          {stableImages.map((src, index) => (
            <ImageCard key={src} src={src} district={district} index={index} />
          ))}
        </div>
      </div>
    </main>
  );
}
